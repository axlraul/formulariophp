<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión contactos aplicativos por Sistema</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        p {
            text-align: left;
            margin-bottom: 10px;
        }

        form {
            text-align: left;
            margin: 0 auto;
            width: 80%;
        }

        textarea {
            width: 50%;
            height: 150px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            color: #777;
            white-space: pre-line;
        }

        label {
            font-weight: bold;
            color: #007bff;
            display: block;
            margin-bottom: 5px;
        }

        select, input[type="text"] {
            width: 110px;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            display: inline-block;
        }

        input[type="text"].expanded {
            width: 300px; /* Tamaño triplicado para los campos PARA y CC */
        }

        input[type="submit"], input[type="button"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: #0056b3;
        }

        #output {
            margin-top: 40px;
            margin-bottom: 20px;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }

        strong {
            color: #333;
        }

        pre {
            background-color: #f8f8f8;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow-x: auto;
        }
    </style>
</head>
<body>

<form action="" method="post">

    <h2>Gestión contactos aplicativos por Sistema</h2>

    <p>
        <label for="campo_nombre_sistema">Sistema:</label>
        <input type="text" name="campo_nombre_sistema" id="campo_nombre_sistema" maxlength="5">
    </p>

    <p>
        <label for="opciones">Acción:</label>
        <select name="opciones" id="opciones">
            <option value="" disabled selected>Selecciona</option>
            <option value="crear">Crear</option>
            <option value="modificar">Modificar</option>
            <option value="consultar">Consultar</option>
        </select>
    </p>

    <div id="campos_crear_modificar" style="display: none;">
        <p>
            <label for="campo1">PARA:</label>
            <input type="text" name="campo1" id="campo1" class="expanded example-text" value="contacto1,contacto2" onfocus="if (this.value == 'contacto1,contacto2') { this.value = ''; this.style.color = '#000'; }" onblur="if (this.value == '') { this.value = 'contacto1,contacto2'; this.style.color = '#777'; }">
        </p>

        <p>
            <label for="campo2">CC:</label>
            <input type="text" name="campo2" id="campo2" class="expanded example-text" value="contacto1,contacto2" onfocus="if (this.value == 'contacto1,contacto2') { this.value = ''; this.style.color = '#000'; }" onblur="if (this.value == '') { this.value = 'contacto1,contacto2'; this.style.color = '#777'; }">
        </p>

        <p>
            <label for="campo3">Email TS:</label>
            <input type="text" name="campo3" id="campo3">
            <span style="font-weight: bold; text-decoration: underline;">
                <br>
                <strong><u>Nota:</u></strong> El campo <strong>TS</strong> <strong>ÚNICAMENTE</strong> se debe definir
                si la <strong>TS primaria NO es</strong> la <strong><u>Linux Infra Corp</u></strong>.
            </span>
        </p>
    </div>

    <p>
        <input type="submit" value="Ejecutar acción">
        <input type="button" value="Volver a inicio" onclick="window.location.href='../index.php'">
    </p>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $opcionSeleccionada = $_POST["opciones"];
    $nombreSistema = $_POST["campo_nombre_sistema"];
    $para = $_POST["campo1"];
    $cc = $_POST["campo2"];
    $ts = $_POST["campo3"];

    $script = "/tools/scripts/notificaciones-apars_ipl/show_create_modify_contacts.sh";

    // Construir la cadena de comandos
    $comando = "sh $script $opcionSeleccionada $nombreSistema $para $cc $ts";

    // Ejecutar el script y obtener la salida
    $output = shell_exec($comando);

    // Mostrar la salida del script por pantalla
    echo '<div id="output"><strong>Resultado:</strong><br><pre>' . $output . '</pre></div>';
}
?>

<script>
    document.getElementById('opciones').addEventListener('change', function() {
        var camposCrearModificar = document.getElementById('campos_crear_modificar');
        camposCrearModificar.style.display = (this.value === 'crear' || this.value === 'modificar') ? 'block' : 'none';
    });
</script>

</body>
</html>

