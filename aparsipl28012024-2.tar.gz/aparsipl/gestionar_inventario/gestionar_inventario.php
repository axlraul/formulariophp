<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de inventario de nodos</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin: 20px 0;
        }

        p {
            text-align: left;
            margin-left: 0px;
            margin-bottom: 10px;
            margin-top: 0;
        }

        form {
            text-align: left;
            margin: 0 auto;
            width: 80%;
        }

        label {
            font-weight: bold;
            color: #007bff;
            display: block;
            margin-bottom: 5px;
            margin-top: 10px;
        }

        input, select {
            width: 200px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            display: block;
        }

        textarea {
            width: 100%;
            height: 200px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            color: #777;
            white-space: pre-line;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            width: 200px;
            display: inline-block;
            margin-top: 10px;
            margin-right: 10px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            width: 200px;
            display: inline-block;
            margin-top: 10px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .mensaje-exito {
            margin-top: 20px;
        }

        .mensaje-error {
            color: #ff0000;
        }

        #resultado {
            margin-left: 148px;
        }
    </style>
</head>
<body>

<?php

$output = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verificar la opción seleccionada
    $opcion = $_POST['opcion'];

    // Ejecutar la acción correspondiente
    if ($opcion == 'Consultar') {
        $consultaTexto = isset($_POST['consulta_texto']) ? $_POST['consulta_texto'] : '';
        $output = shell_exec("/tools/scripts/notificaciones-apars_ipl/admin_inventory.sh $opcion $consultaTexto 2>&1");
    } elseif ($opcion == 'Insertar' || $opcion == 'Eliminar') {
        $nodo = isset($_POST['nodo']) ? $_POST['nodo'] : '';
        $sistema = isset($_POST['sistema']) ? $_POST['sistema'] : '';
        $sistemaOperativo = isset($_POST['sistema_operativo']) ? $_POST['sistema_operativo'] : '';
#       $output = shell_exec("/tools/scripts/notificaciones-apars_ipl/admin_inventory.sh $nodo" "$sistema" "$sistemaOperativo" 2>&1");

$output = shell_exec("/tools/scripts/notificaciones-apars_ipl/admin_inventory.sh $opcion \"$nodo\" \"$sistema\" \"$sistemaOperativo\" 2>&1");

    }
}

?>

<h2>Gestión de inventario de nodos</h2>
<br>

<form method="post" action="">
    <p>Elige una opción para consultar, crear, insertar o eliminar registros en el inventario de nodos de esta aplicación.</p>
    <br>
    <label for="opcion">Opción:</label>
    <select name="opcion" id="opcion">
        <option value="" disabled selected>Selecciona por defecto</option>
        <option value="Consultar">Consultar</option>
        <option value="Insertar">Insertar</option>
        <option value="Eliminar">Eliminar</option>
    </select>

    <div id="consulta" style="display: none;">
        <label for="consulta_texto">Texto para consultar:</label>
        <input type="text" name="consulta_texto" id="consulta_texto">
    </div>

    <div id="insertar_eliminar" style="display: none;">
        <label for="nodo">Nodo:</label>
        <input type="text" name="nodo" id="nodo">
        <label for="sistema">Sistema:</label>
        <input type="text" name="sistema" id="sistema">
        <label for="sistema_operativo">Sistema Operativo:</label>
        <input type="text" name="sistema_operativo" id="sistema_operativo">
    </div>

    <!-- Mostrar el botón "Ejecutar" solo si se selecciona una opción -->
    <input type="submit" value="Ejecutar" style="display: none;" id="ejecutar_btn">
    <a href="../index.php"><button type="button">Volver al inicio</button></a>
</form>

<div id="resultado">
    <?php
    // Mostrar el resultado del script
    if (!empty($output)) {
        echo "<p class='mensaje-exito'>Resultado: <pre>$output</pre></p>";
    }
    ?>
</div>

<script>
    // Mostrar u ocultar campos y botón según la opción seleccionada
    var opcionElement = document.getElementById('opcion');
    var consultaDiv = document.getElementById('consulta');
    var insertarEliminarDiv = document.getElementById('insertar_eliminar');
    var ejecutarBtn = document.getElementById('ejecutar_btn');

    function mostrarOcultarCamposYBoton() {
        var opcionSeleccionada = opcionElement.value;
        consultaDiv.style.display = (opcionSeleccionada === 'Consultar') ? 'block' : 'none';
        insertarEliminarDiv.style.display = (opcionSeleccionada === 'Insertar' || opcionSeleccionada === 'Eliminar') ? 'block' : 'none';
        ejecutarBtn.style.display = (opcionSeleccionada !== '') ? 'inline-block' : 'none';
    }

    // Llamar a la función al cargar la página
    mostrarOcultarCamposYBoton();

    // Mostrar u ocultar campos y botón al cambiar la opción seleccionada
    opcionElement.addEventListener('change', mostrarOcultarCamposYBoton);
</script>

</body>
</html>

