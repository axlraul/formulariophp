<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center; 
            color: #333;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 20px 0;
            text-align: left; 
        }

        li {
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
            margin-left: 140px;
        }

        a:hover {
            color: #0056b3;
        }

        #resultados {
            text-align: center;
            margin-top: 20px;
            position: relative;
        }

        #resultados p {
            font-size: 70%;
            margin: 0;
            display: inline-block; /* Coloca ambos párrafos en la misma línea */
        }

        /* estilo adicional para separar los dos párrafos */
        #resultados p + p {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h2>Gestión notificaciones por e-mail APARS/IPL</h2>
    <br>
    <br>
    <ul>
        <li><a href="envio_notificaciones/formulario_envio_apars_ipl.php">Envío planificaciones APARS/IPL a aplicación automatizado</a></li>
        <li><a href="consulta_cambios/consulta_cambios.php">Consulta histórico de planificaciones enviadas</a></li>
        <li><a href="consulta_correos/consulta_correos.php">Consulta histórico de correos enviados</a></li>
        <li><a href="gestionar_contactos/gestionar_contactos.php">Gestión contactos de Sistemas</a></li>
        <li><a href="gestionar_inventario/gestionar_inventario.php">Gestión nodos en inventario</a></li>
    </ul>

    <?php
        $ruta_a_lista = "/tools/scripts/notificaciones-apars_ipl/escalation/HISTORICO/";
        $ruta_a_correos_enviados = "/tools/scripts/notificaciones-apars_ipl/escalation/SENT_MAILS/";
        $resultado1 = shell_exec("cat $ruta_a_lista* | wc -l");
        $resultado2 = shell_exec("ls -la $ruta_a_correos_enviados | tail -n +3 | wc -l");
    ?>

    <div id="resultados">
        <br><br><br>
        <p>Núm. nodos planificados: <?php echo $resultado1; ?></p>
        <p> - </p>
        <p>Núm. e-mails enviados: <?php echo $resultado2; ?></p>
    </div>
</body>
</html>

