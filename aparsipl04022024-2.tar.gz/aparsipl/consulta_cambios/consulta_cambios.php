<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta histórico de planificaciones enviadas</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        #content {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            height: 100vh;
            margin-top: 50;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            text-align: left;
            margin: 0 auto;
            width: 80%;
        }

        label {
            font-weight: bold;
            color: #007bff;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 200px;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .disclaimer {
            color: #777;
        }
    </style>
</head>
<body>

<div id="content">
    <br>
    <h2>Consulta histórico de planificaciones enviadas</h2>
    <form action="" method="post">
        <label for="patron_busqueda">Patrón de Búsqueda:</label>
        <input type="text" name="patron_busqueda" id="patron_busqueda">
        <button type="submit" name="buscar">Buscar</button>
        <p class="disclaimer">Ten en cuenta que las opciones que se pueden utilizar para buscar son las del comando grep </p>
    </form>
    <?php
    if (isset($_POST['buscar'])) {
        $script_validacion_planificacion = '/tools/scripts/notificaciones-apars_ipl/search_apars_ipls.sh';
        $patron_busqueda = isset($_POST['patron_busqueda']) ? $_POST['patron_busqueda'] : '';

        // Escapar el patrón de búsqueda para evitar problemas de seguridad
        $patron_busqueda = escapeshellarg($patron_busqueda);

        // Construir el comando para ejecutar el script de Bash con el argumento
        $comando = "$script_validacion_planificacion $patron_busqueda";

        // Ejecutar el comando y obtener la salida
        $resultado = shell_exec($comando);

        // Imprimir o manejar el resultado como desees
        echo "<div>Resultado de la ejecución del script:<br>$resultado</div>";
    }
    ?>

    <form action="../index.php">
        <button type="submit" class="volver-btn">Volver a inicio</button>
    </form>
</div>

</body>
</html>

