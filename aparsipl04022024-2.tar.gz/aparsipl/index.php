<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 20px 0;
            text-align: left;
        }

        li {
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
            margin-left: 140px;
        }

        a:hover {
            color: #0056b3;
        }

        #resultados {
            text-align: center;
            margin-top: 20px;
            position: relative;
        }

        #resultados p {
            font-size: 70%;
            margin: 0;
            display: inline-block; /* Coloca ambos párrafos en la misma línea */
        }

        /* estilo adicional para separar los dos párrafos */
        #resultados p + p {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <br>
    <h2>Gestión notificaciones por e-mail APARS/IPL</h2>
    <br>
    <br>
    <ul>
        <li><a href="envio_notificaciones/formulario_envio_apars_ipl.php">Envío planificaciones APARS/IPL a aplicación automatizado</a></li>
        <li><a href="consulta_cambios/consulta_cambios.php">Consulta histórico de planificaciones enviadas</a></li>
        <li><a href="consulta_correos/consulta_correos.php">Consulta histórico de correos enviados</a></li>
        <li><a href="gestionar_contactos/gestionar_contactos.php">Gestión contactos de Sistemas</a></li>
        <li><a href="gestionar_inventario/gestionar_inventario.php">Gestión nodos en inventario</a></li>
    </ul>

    <?php
        $ruta_a_lista = "/tools/scripts/notificaciones-apars_ipl/escalation/HISTORICO/";
        $ruta_a_correos_enviados = "/tools/scripts/notificaciones-apars_ipl/escalation/SENT_MAILS/";
        $resultado1 = shell_exec("cat $ruta_a_lista* | wc -l");
        $resultado2 = shell_exec("ls -la $ruta_a_correos_enviados | tail -n +3 | wc -l");

        // Obtener la fecha y hora actual
        $fechaActual = new DateTime();

        // Contador para APARS/IPL en vuelo
        $contadorAparIplEnVuelo = 0;

        // Obtener la lista de archivos en el directorio
        $archivos = glob($ruta_a_lista . "*");

        // Verificar cada fecha y contar las futuras y pasadas
        foreach ($archivos as $archivo) {
            $lineas = file($archivo);
            foreach ($lineas as $linea) {
                // Utilizar una expresión regular para extraer la fecha
                if (preg_match('/\b(\d{2}\/\d{2}\/\d{4})\b/', $linea, $matches)) {
                    $fechaTexto = $matches[1];
                    $fecha = DateTime::createFromFormat('d/m/Y', $fechaTexto);

                    // Verificar si la fecha es del futuro o del pasado
                    if ($fecha && $fecha > $fechaActual) {
                        $contadorAparIplEnVuelo++;
                    }
                }
            }
        }
    ?>

    <div id="resultados">
        <br><br><br>
        <p>Nº nodos planificados: <?php echo $resultado1; ?></p>
        <p> - </p>
        <p>Nº planificaciones en vuelo: <?php echo $contadorAparIplEnVuelo; ?></p>
        <p> - </p>
        <p>Nº e-mails enviados: <?php echo $resultado2; ?></p>
    </div>
</body>
</html>

