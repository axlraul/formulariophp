<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Fechas desde TXT</title>
</head>
<body>
    <h1>Fechas desde el archivo de texto</h1>
    <?php
    $archivo = '/tools/scripts/notificaciones-apars_ipl/escalation/HISTORICO/HISTORICO-2024.txt';

    // Verificar si el archivo existe
    if (file_exists($archivo)) {
        // Leer el contenido del archivo línea por línea
        $lineas = file($archivo, FILE_IGNORE_NEW_LINES);

        // Obtener la fecha y hora actual
        $fechaActual = new DateTime();

        // Contador para APARS/IPL en vuelo
        $contadorAparIplEnVuelo = 0;

        // Contador para fechas pasadas
        $contadorPasadas = 0;

        // Contador para Núm. nodos planificados
        $contadorNodosPlanificados = 0;

        // Verificar cada fecha y contar las futuras y pasadas
        foreach ($lineas as $linea) {
            // Utilizar una expresión regular para extraer la fecha
            if (preg_match('/\b(\d{2}\/\d{2}\/\d{4})\b/', $linea, $matches)) {
                $fechaTexto = $matches[1];
                $fecha = DateTime::createFromFormat('d/m/Y', $fechaTexto);

                // Verificar si la fecha es del futuro o del pasado
                if ($fecha) {
                    if ($fecha > $fechaActual) {
                        $contadorAparIplEnVuelo++;
                    } else {
                        $contadorPasadas++;
                    }
                }
                $contadorNodosPlanificados++;
            }
        }

        // Mostrar el resultado del conteo
        echo '<p>APARS/IPL en vuelo: ' . $contadorAparIplEnVuelo . '</p>';
        echo '<p>Fechas pasadas: ' . $contadorPasadas . '</p>';
        echo '<p>Núm. nodos planificados: ' . $contadorNodosPlanificados . '</p>';
    } else {
        echo 'El archivo no existe.';
    }
    ?>
</body>
</html>

