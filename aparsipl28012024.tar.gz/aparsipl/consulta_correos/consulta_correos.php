<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta histórico de correos enviados</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
/*            font-size: 1em;*/
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        li {
            margin-bottom: 1px; /* Reducida la separación entre resultados */
        }

        a {
            display: block;
            padding: 7px;
            background-color: #fff;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #333;
            font-size: 0.8em;
        }

        a:hover {
            background-color: #f9f9f9;
        }

        .volver {
            text-align: center;
            margin-top: 5px;
        }

        .volver a {
            display: inline-block;
            padding: 7px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            font-size: 0.8em;
        }

        .volver a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<?php
$directorio = "/tools/scripts/notificaciones-apars_ipl/escalation/SENT_MAILS";

if (isset($_GET['archivo'])) {
    $archivoSeleccionado = $_GET['archivo'];
    $rutaCompleta = $directorio . '/' . $archivoSeleccionado;

    if (file_exists($rutaCompleta)) {
        // Utiliza shell_exec para ejecutar el comando cat
        $contenido = shell_exec('cat ' . escapeshellarg($rutaCompleta));

        // Muestra el contenido del archivo HTML
        echo '<h2>Email enviado ' . $archivoSeleccionado . '</h2>';
        echo $contenido;

        // Botón "Volver a inicio"
        echo '<div class="volver">';
        echo '<a href="../index.php">Volver a inicio</a>';
        echo '</div>';
    } else {
        echo '<p>El archivo no existe.</p>';
    }
} else {
    // Muestra el listado de archivos en el directorio
    $archivos = scandir($directorio);
    echo '<h2>Consulta histórico de correos enviados</h2>';
    echo '<ul>';
    foreach ($archivos as $archivo) {
        if ($archivo != '.' && $archivo != '..') {
            // Enlace a la misma página con el nombre del archivo como parámetro
            echo '<li><a href="?archivo=' . urlencode($archivo) . '">' . $archivo . '</a></li>';
        }
    }
    echo '</ul>';

    // Botón "Volver a inicio"
    echo '<div class="volver">';
    echo '<a href="../index.php">Volver a inicio</a>';
    echo '</div>';
}
?>

</body>
</html>

