<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envío planificaciones APARS/IPL - Resultado envío planificación</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        pre {
            background-color: #fff;
            padding: 10px;
            border: 1px solid #ddd;
            white-space: pre-wrap; /* Permite saltos de línea */
        }

        .buttons-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            margin: 0 5px; /* Pequeño margen horizontal */
            text-decoration: none; /* Elimina el subrayado */
        }

        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h2>Envío planificaciones APARS/IPL - Resultado envío planificación</h2>
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_planificacion'])) {
        $tipo_planificacion = $_POST['tipo_planificacion'];
        $nombre_tecnico = $_POST['nombre_tecnico'];
        $archivo_planificacion = $_POST['archivo_planificacion'];
        $script_envio_mail = '/tools/scripts/notificaciones-apars_ipl/send_planification.sh';

        // Ejecutar el script de Bash (o PHP) con la opción como argumento y obtener la salida
        $output_otro_php = shell_exec("$script_envio_mail $tipo_planificacion $nombre_tecnico 2>&1");

        echo "Resultado del envío de la planificación:<br>";
        echo "<pre>$output_otro_php</pre>";  // Utilizando <pre> para conservar el formato del texto
    } else {
        echo "Acceso no permitido.";
    }
    ?>

    <div class="buttons-container">
        <a href="formulario_envio_apars_ipl.php" class="button">Volver a Planificar</a>
        <a href="../index.php" class="button">Volver a Inicio</a>
    </div>
</body>
</html>

