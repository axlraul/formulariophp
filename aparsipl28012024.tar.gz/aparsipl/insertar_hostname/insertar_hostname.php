<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión contactos aplicativos por Sistema</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin: 20px 0;
        }

        p {
            text-align: left;
            margin-left: 146px;
            margin-bottom: 10px;
            margin-top: 0;
        }

        form {
            text-align: left;
            margin: 0 auto;
            width: 80%;
        }

        label {
            font-weight: bold;
            color: #007bff;
            display: block;
            margin-bottom: 5px;
        }

        input, select {
            width: 200px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            display: block;
        }

        textarea {
            width: 100%;
            height: 200px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            color: #777;
            white-space: pre-line;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            width: 200px;
            display: inline-block; /* Cambiado a inline-block */
            margin-top: 10px; /* Ajuste del margen superior */
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            width: 200px;
            display: inline-block; /* Cambiado a inline-block */
            margin-top: 10px; /* Ajuste del margen superior */
            margin-left: 10px; /* Ajuste del margen izquierdo */
        }

        button:hover {
            background-color: #0056b3;
        }

        .mensaje-exito {
            margin-top: 70px; /* Ajuste de la posición vertical */
        }

        .mensaje-error {
            color: #ff0000; /* Color rojo para mensajes de error */
        }
    </style>
</head>
<body>
    <h2>Gestión de contactos aplicativos por Sistema</h2>
    <br><br>
    <p>Para añadir nodos al inventario de esta herramienta, cumplimenta los campos que se muestran a continuación:</p>
    <br>
    <form method="POST" action="">
        <label for="nodo">Nodo:</label>
        <input type="text" id="nodo" name="nodo" required>

        <label for="sistema">Sistema:</label>
        <input type="text" id="sistema" name="sistema" required>

        <label for="sistema_operativo">Sistema Operativo:</label>
        <input type="text" id="sistema_operativo" name="sistema_operativo" required>
        <br>
        <input type="submit" value="Añadir">
        <!-- Botón para volver a inicio -->
        <button type="button" onclick="window.location.href='../index.php'">Volver a inicio</button>
    </form>

    <?php

    // Nombre del archivo
    $nombre_archivo = '/tools/scripts/notificaciones-apars_ipl/inventory/inventory.txt';

    // Manejar el envío del formulario
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Obtener valores del formulario
        $nodo = $_POST['nodo'];
        $sistema = $_POST['sistema'];
        $sistema_operativo = $_POST['sistema_operativo'];

        // Validar que no haya espacios en las variables nodo y sistema
        if (strpos($nodo, ' ') === false && strpos($sistema, ' ') === false) {
            // Construir la cadena a agregar en la última línea del archivo
            $linea_a_agregar = "$nodo $sistema $sistema_operativo #added manually";

            // Leer el contenido actual del archivo
            $contenido_actual = file_get_contents($nombre_archivo);

            // Agregar la nueva línea al final del contenido con un salto de línea
            $contenido_actual .= PHP_EOL . $linea_a_agregar . PHP_EOL;

            // Escribir el contenido actualizado de vuelta al archivo
            file_put_contents($nombre_archivo, $contenido_actual);
            echo '<p class="mensaje-exito">Valores añadidos correctamente al archivo.</p>';
        } else {
            echo '<p class="mensaje-error">Error: Nodo y Sistema no deben contener espacios.</p>';
        }
    }

    ?>

</body>
</html>

