#!/bin/bash

cabecera='NODO\t\tSISTEMA\tTIPO\tCODIGO\t\tFECHA\t\t\tSISTEMA OPERATIVO\t'

clear
echo "-------------------------------------------"
echo "Buscador APARS/IPL"
echo "Raul Perez"
echo "TS Linux Infra Corp"
echo "20/01/2024"
echo "-------------------------------------------"
echo "Elige una opcion:"
echo "1)      Busqueda historitco APARS/IPL de un sistema"
echo "2)      Busqueda historico APARS/IPL de un nodo"
echo "3)      Busqueda historico CH APARS/IPL"
echo "4)      Busqueda historico por palabra clave"
echo "q) Salir"
echo ""
echo ""
read preferencia

case "$preferencia" in
  "1")
    TIPO_BUSQUEDA='BUSQUEDA_SISTEMA'
    ;;
  "2")
    TIPO_BUSQUEDA='BUSQUEDA_NODO'
    ;;
  "3")
    TIPO_BUSQUEDA='BUSQUEDA_CH'
    ;;
  "4")
    TIPO_BUSQUEDA='BUSQUEDA_WILDCARD'
    ;;

  "q")
    echo "Saliendo del programa."
    exit 0
    ;;
  *)
    echo "Opcion no valida. Por favor, ingresa '1', '2', '3' o '4'."
    exit 1
    ;;
esac

echo "Indica el parametro de busqueda:"
read parametro_busqueda

##realmente unicamente se realiza un grep -w, por lo que no se requiere mas inteligencia para realizar la busqueda que esta. el case esta hecho para que el tecnico sepa como puede buscar en los logs
if [[ $TIPO_BUSQUEDA != 'BUSQUEDA_WILDCARD' ]]; then
   echo ""
   echo "Busqueda historico APARS/IPL"
   echo ""
   resul=$(grep -hw $parametro_busqueda escalation/HISTORICO/HISTORICO-*) 
   if [[ $(echo $resul) == "" ]]; then
      echo "No se han encontrado resultados"
   else
      echo "Resultados de la busqueda por sistema $parametro_busqueda"
      echo -e "$cabecera"
      echo "$resul"
   exit 0
   fi
fi

if [[ $TIPO_BUSQUEDA == 'BUSQUEDA_WILDCARD' ]]; then
   echo ""
   echo "Busqueda historico APARS/IPL mediante wildcard"
   echo ""
   resul=$(grep -i $parametro_busqueda escalation/HISTORICO/HISTORICO-*)
   if [[ $(echo $resul) == "" ]]; then
      echo "No se han encontrado resultados"
   else
      echo "Resultados de la busqueda por sistema $parametro_busqueda"
      echo -e "$cabecera"
      echo "$resul"
   exit 0
   fi
fi

unset resul
unset TIPO_BUSQUEDA
unset cabecera
unset parametro_busqueda
unset preferencia
