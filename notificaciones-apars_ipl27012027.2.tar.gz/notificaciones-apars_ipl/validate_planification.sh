#!/bin/bash
#export TERM=xterm

PATH_BASE="/tools/scripts/notificaciones-apars_ipl"
INVENTORY="$PATH_BASE/inventory/inventory.txt"
fecha_hora=$(date "+%d%m%y-%H%M%S")
archivo="$PATH_BASE/planification/planification_list.txt"
#DIR_MAILS='MAILS' 

TECHNICIAN_TAG="$2"

# Inicializar variables
nodo=""
tipo_cambio=""
cambio=""
fecha=""
so=""
system_found=""
mail_para=""
mail_cc=""
file_body_mail=""

#su - root -c "dos2unix -f /tools/scripts/notificaciones-apars_ipl/planification_list2.txt"
########sudo dos2unix -f /tools/scripts/notificaciones-apars_ipl/planification_list.txt
# Limpiando e-mails enviados anteriormente
#clear
echo "-------------------------------------------"
echo "Validacion de lista de de nodos para notificaciones APARS/IPL"
echo "Raul Perez"
echo "TS Linux Infra Corp"
echo "20/01/2024"
echo "-------------------------------------------"
echo ""

case $TECHNICIAN_TAG in
   RAULPS)
     TECHNICIAN_FULLNAME='Raúl Pérez Sanchiz'
     ;;
   JOSEMMC)
     TECHNICIAN_FULLNAME='Jose María Manero Caballero'
     ;;
   JOSEAAS)
     TECHNICIAN_FULLNAME='Jose Antonio Álvarez Sotoca'
     ;;
   JACOBOAE)
     TECHNICIAN_FULLNAME='Jacobo Saúl Arvelo Estevez'
     ;;
   SERGISD)
     TECHNICIAN_FULLNAME='Sergi Surroca Díaz'
     ;;
   JORDIFG)
     TECHNICIAN_FULLNAME='Jordi Francés García'
     ;;
esac

##setting planification type

case "$1" in
  "A")
    TIPO_PLANIFICACION='APARS_SO'
    ;;
  "APACHE")
    TIPO_PLANIFICACION='APARS_APACHE'
    ;;
  "I")
    TIPO_PLANIFICACION='IPL'
    ;;
  "q")
    echo "Saliendo del programa."
    exit 0
    ;;
  *)
    echo "Opcion no valida. Por favor, ingresa 'A' o 'I'."
    exit 1
    ;;
esac


if [ -z "$(cat "$archivo")" ]; then
   echo "Existe un problema con el archivo que recoge las planificaciones a enviar. el archiv es planification_list.txt y debe tener permisos apache:root. "
   exit 1
else
   ##### 24012024 Fix that allows to imput a planification list with n blank lines and delete all before reading all lines by script 
   #Adding blank line

   echo "" >> "$archivo"
   #deleting all blank lines at file
   sed -i '/^$/d' "$archivo"
#   sed -i -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$archivo"
  
   ####

   echo ""
   echo "Tipo planificacion elegida: $TIPO_PLANIFICACION"
   echo "Planificacion a enviar por $TECHNICIAN_FULLNAME"
   echo ""
   # Adding headers to show list at web
   echo "Formato:"
   echo -e 'NODO\t\tSISTEMA\tTIPO\tCODIGO\t\tFECHA\t\t\tSISTEMA OPERATIVO\t'
fi 

while IFS= read -r linea; do
    case $((contador % 5)) in
        0)
            nodo="$linea"
            if [[ $(cat $INVENTORY | grep $nodo | wc -l) != 1 ]]; then
               echo "$linea *** Error - El nodo no se encuentra en inventory/inventory.txt. Revisa este listado y el nombre del nodo antes de continuar"
               exit 1
            fi
            system_found="$(cat $INVENTORY | grep -w $linea | egrep -i "linux|red hat" | awk '{print $2}')"
            ;;
        1)
            tipo_cambio="$linea"
            ;;
        2)
            cambio="$linea"
            ;;
        3)
            fecha="$linea"
            ;;
        4)
            so="$linea"
            if [[ $(echo $so | egrep -i "linux|red" | wc -l) == 0 ]]; then
               echo "ERROR - El nodo $nodo no es de un sistema Linux o Red Hat. Es SO $so Revisa el listado inventory/inventory.txt y el nombre del nodo antes de continuar"
               exit 1
            fi

    if [[ -f "$PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found" ]]; then
      if [[ $(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | grep "PARA:" | wc -l) == 1 ]]; then
         mail_para="$(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | grep "PARA:" | awk -F "\"" '{print $2}')"
      else
         echo "ERROR - Faltan los destinatarios en PARA para el sistema $system_found"
#         echo "ERROR - Faltan los destinatarios en PARA para el sistema $system_found" >> $PATH_BASE/escalation/MAILS/$system_found
      fi
      if [[ $(grep "CC:" $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | wc -l) == 1 ]]; then
         mail_cc="$(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | grep "CC:" | awk -F "\"" '{print $2}')"
      else
         echo "ERROR - Faltan los destinatarios en CC para el sistema $system_found"
 #        echo "ERROR - Faltan los destinatarios en CC para el sistema $system_found"  >> $PATH_BASE/escalation/MAILS/$system_found
      fi
    else
         echo "ERROR - Archivo de escalado escalation/CONTACTS_SYSTEMS/$system_found no existe. Crealo con la siguiente nomenclatura:"
         echo "  PARA:\"correo1,correo2\""
         echo "  CC:\"correo3,correo4\""
#         echo "ERROR - Archivo de escalado escalation/CONTACTS_SYSTEMS/$system_found no existe. Crealo con la siguiente nomenclatura:"  >> $PATH_BASE/escalation/MAILS/$system_found
#         echo "  PARA:\"correo1,correo2\""  >> $PATH_BASE/escalation/MAILS/$system_found
#         echo "  CC:\"correo3,correo4\""  >> $PATH_BASE/escalation/MAILS/$system_found
    fi

      echo -e "${nodo[$i]}\t${system_found[$i]}\t${tipo_cambio[$i]}\t${cambio[$i]}\t${fecha[$i]}\t${so[$i]}"
#     printf "%-15s %-15s %-15s %-15s %-25s %-25s\n" "${nodo[$i]}" "${system_found[$i]}" "${tipo_cambio[$i]}" "${cambio[$i]}" "${fecha[$i]}" "${so[$i]}" 


#    echo "Nodo: $nodo" >> escalation/MAILS/$system_found
#    echo "Sistema: $system_found" >> escalation/MAILS/$system_found
#    echo "Tipo de cambio: $tipo_cambio" >> escalation/MAILS/$system_found
#    echo "Codigo de cambio: $cambio" >> escalation/MAILS/$system_found
#    echo "Fecha: $fecha" >> escalation/MAILS/$system_found
#    echo "SO: $so" >> escalation/MAILS/$system_found
#    echo "-----------" >> escalation/MAILS/$system_found


    unset nodo
    unset system_found
    unset tipo_cambio
    unset cambio
    unset fecha
    unset so
    unset mail_para
    unset mail_cc
      esac

    # Incrementar el contador
    ((contador++))
done < "$archivo"

unset system_name
unset file_body_mail
unset TIPO_PLANIFICACION

