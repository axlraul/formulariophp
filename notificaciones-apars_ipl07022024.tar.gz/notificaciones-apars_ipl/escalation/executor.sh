#!/bin/bash

# Nombre del archivo de entrada
input_file="listado_infra.txt"
output_path="CONTACTS_SYSTEMS"
rm -Rf CONTACTS_SYSTEMS/*
sed -i 's/"//g' "$input_file"

while IFS= read -r line; do
    if [[ $line == *SISTEMA* ]]; then
        system_found=$(echo "$line" | awk -F ':' '{print $2}' | tr -d '[:space:]')

        read -r para_line
        read -r cc_line
        PARA_FOUND=$(echo "$para_line" | awk -F 'PARA:' '{print $2}' | tr -d '[:space:]')
#        sed -i "s/$para_line/PARA:\"$PARA_FOUND\"/g" "$input_file"

        CC_FOUND=$(echo "$cc_line" | awk -F 'CC:' '{print $2}' | tr -d '[:space:]')
#        sed -i "s/$cc_line/CC:\"$CC_FOUND\"/g" "$input_file"

        PARA_FOUND="\"$PARA_FOUND\""
        CC_FOUND="\"$CC_FOUND\""

        echo "system_found:$system_found"
        echo "PARA_FOUND:$PARA_FOUND"
        echo "CC_FOUND:$CC_FOUND"
        touch $output_path/$system_found
        echo "PARA:$PARA_FOUND" >> $output_path/$system_found
        echo "CC:$CC_FOUND" >> $output_path/$system_found
    fi
done < "$input_file"

sed -i 's/"//g' "$input_file"

