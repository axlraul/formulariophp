#!/bin/bash

PATH_BASE="/tools/scripts/notificaciones-apars_ipl/escalation"
arg1=$1 #crear / modificar / consultar
arg2=$2 #TTSS
arg3=$3 #email

if [[ $arg1 == 'consultar' ]]; then
  if [[ ! -e "$PATH_BASE/CONTACTS_SYSTEMS/$arg2" ]]; then
    echo "Contacto de la TS $arg2 no está presente en $PATH_BASE/CONTACTS_SYSTEMS/$arg2."
    echo "Utiliza la opcion Crear"
  else
    echo "Contacto de la TS $arg2:"
    cat $PATH_BASE/CONTACTS_SYSTEMS/$arg2
  fi
elif [[ $arg1 == 'crear' ]]; then
  if [[ ! -e "$PATH_BASE/CONTACTS_SYSTEMS/$arg2" ]]; then
     echo "$arg3" > $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     echo "Contacto de la TS $arg2 creado"
  else 
    echo "Contacto de la TTSS presente en $PATH_BASE/CONTACTS_SYSTEMS/$arg2."
    echo "Utiliza la opcion Consultar/Modificar."
  fi
elif [[ -e "$PATH_BASE/CONTACTS_SYSTEMS/$arg2" ]]; then
  if [[ $arg1 == 'modificar' ]]; then
     rm -f $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     echo "$arg3" > $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     echo "Contactos de la TS $arg2 modificados"
  else 
    echo "Contacto de la TS no está presentes en $PATH_BASE/CONTACTS_SYSTEMS/$arg2."
    echo "Utiliza la opcion Crear"
  fi
fi

unset arg1
unset arg2
unset arg3
unset PATH_BASE
