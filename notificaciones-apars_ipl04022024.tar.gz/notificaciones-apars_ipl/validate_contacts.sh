#!/bin/bash

directorio='escalation/CONTACTS_SYSTEMS'
ESCALATION_CONTACTS=$(find "$directorio" -type f -name "*")

for file in $ESCALATION_CONTACTS; do
    echo "Verificando $file..."
        if [[ $(grep -E '^.*".*".*$' $file | wc -l) != 2 ]]; then
           echo "faltan comillas dobles en el archivo $file. Revisalo, por favor"
        fi

        if [[ $(grep "PARA:" $file | wc -l) != 1 ]]; then
           echo "falta el PARA: en el archivo $file. Revisalo, por favor"
        fi
        if [[ $(grep "CC:" $file | wc -l) != 1 ]]; then
           echo "falta el CC: en el archivo $file. Revisalo, por favor"
        fi

done
