#!/bin/bash
DIR_HISTORICO='/tools/scripts/notificaciones-apars_ipl/escalation/HISTORICO'
#parametro_busqueda=$1
parametro_busqueda=$@


for archivo in $DIR_HISTORICO/HISTORICO-*.txt; do
    echo "Procesando Historico: $archivo"
    echo "<table border="1" cellpadding="3">"
    echo "    <tr>"
    echo "        <th>Nodo</th>"
    echo "        <th>Sistema</th>"
    echo "        <th>Tipo de cambio</th>"
    echo "        <th>Cambio</th>"
    echo "        <th>Fecha propuesta</th>"
    echo "        <th>Sistema Operativo</th>"
    echo "        </tr>"
    while IFS= read -r linea; do

    resul=$(echo $linea | grep $parametro_busqueda)
    if [[ ! -z $resul ]]; then
    	nodo=$(echo $linea | awk '{print $1}')   
        system=$(echo $linea | awk '{print $2}')
	tipo_cambio=$(echo $linea | awk '{print $3}')
	cambio=$(echo $linea | awk '{print $4}')
        fecha=$(echo $linea | awk '{print $5}')
	so=$(echo $linea | awk '{print $6}')
    echo  "<tr><th>${nodo[$i]}</th><th>${system[$i]}</th><th>${tipo_cambio[$i]}</th><th>${cambio[$i]}</th><th>${fecha[$i]}</th><th>${so[$i]}</th></tr>"
    fi
    unset resul
    done < "$archivo"
    echo "</table>"
    echo "Finalizado el procesamiento del archivo: $archivo"
done


unset DIR_HISTORICO
unset archivo
unset resul
unset cabecera
unset parametro_busqueda
unset preferencia
