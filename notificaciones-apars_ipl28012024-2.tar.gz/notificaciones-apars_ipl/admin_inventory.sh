#!/bin/bash
inventario="/tools/scripts/notificaciones-apars_ipl/inventory/inventory.txt"

# Asigna los argumentos a las variables
tipo_accion=$1
var1=$2
var2=$3
#var3=$(echo $4 | awk '{gsub(/'\''/, ""); print}')
var3=$4
# Verifica el tipo de acción
if [ "$tipo_accion" = "Consultar" ]; then
    echo "Resultado de la búsqueda:"
    echo ""
    if [ $(cat $inventario | grep "$var1" | wc -l) -gt 0 ];then
      cat $inventario | grep "$var1"
      echo ""
      echo "Fin resultado de la búsqueda"
    else 
      echo "No se han encontrado resultados para $var1"
    fi
elif [ "$tipo_accion" = "Insertar" ]; then
    # Verifica que los tres parámetros no estén vacíos antes de insertar
    if [ -n "$var1" ] && [ -n "$var2" ] && [ -n "$var3" ]; then
       if [ $(cat $inventario | grep -w "$var1" | grep -w "$var2" | grep -w "$var3" | wc -l) -ge 1 ];then
          echo "Linea '$var1 $var2 "$var3"' ya existente."
          exit 1
       else
          echo ""$var1" "$var2" "$var3"" >> $inventario
          echo "Línea añadida."
          exit 0
       fi
    else
        echo "Error: Todos los parámetros deben tener valores no vacíos para la acción de insertar."
        exit 1
    fi
elif [ "$tipo_accion" = "Eliminar" ]; then
    # Verifica que los tres parámetros no estén vacíos antes de eliminar
    if [ -n "$var1" ] && [ -n "$var2" ] && [ -n "$var3" ]; then
       if [ $(cat $inventario | grep -w "$var1" | grep -w "$var2" | grep -w "$var3" | wc -l) == 0 ];then
          echo "Linea '$var1 $var2 $var3' no existe."
          exit 1
       else
          sed -i "/^$var1 $var2 $var3$/d" $inventario
          echo "Líneas eliminadas."
          exit 0
       fi
    else
        echo "Error: Todos los parámetros deben tener valores no vacíos para la acción de eliminar."
        exit 1
    fi
else
    echo "Error: Tipo de acción no válido."
    exit 1
fi

