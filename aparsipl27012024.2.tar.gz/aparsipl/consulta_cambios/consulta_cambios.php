<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta histórico de planificaciones enviadas</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2,
        label,
        button,
        .volver-btn,
        .disclaimer,
        div {
            margin: 0;
            padding: 10px;
            box-sizing: border-box;
            background-color: transparent;
            border: 1px solid transparent;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            text-align: left;
            margin: 20px auto;
            width: 80%;
        }

        label {
            font-weight: bold;
            color: #007bff;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 20%;
            padding: 8px;
            margin-bottom: 10px;
            background-color: #fff; /* Establecer el fondo del cuadro de texto a blanco */
            border: 1px solid #ddd; /* Establecer el borde del cuadro de texto */
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        div {
            text-align: left;
            margin: 20px auto;
            width: 80%;
        }

        .volver-btn {
            background-color: #007bff;
            color: #fff;
            margin-top: 20px;
            display: block;
            margin: 20px auto;
        }

        .disclaimer {
            margin-top: -10px;
            color: #777;
        }
    </style>
</head>
<body>

<div>
    <h2>Consulta histórico de planificaciones enviadas</h2>
    <form action="" method="post">
        <label for="patron_busqueda">Patrón de Búsqueda:</label>
        <input type="text" name="patron_busqueda" id="patron_busqueda">
        <button type="submit" name="buscar">Buscar</button>
        <p class="disclaimer">Ten en cuenta que las opciones que se pueden utilizar para buscar son las del comando grep </p>
    </form>
    <?php
    if (isset($_POST['buscar'])) {
        $script_validacion_planificacion = '/tools/scripts/notificaciones-apars_ipl/search_apars_ipls.sh';
        $patron_busqueda = isset($_POST['patron_busqueda']) ? $_POST['patron_busqueda'] : '';

        // Escapar el patrón de búsqueda para evitar problemas de seguridad
        $patron_busqueda = escapeshellarg($patron_busqueda);

        // Construir el comando para ejecutar el script de Bash con el argumento
        $comando = "$script_validacion_planificacion $patron_busqueda";

        // Ejecutar el comando y obtener la salida
        $resultado = shell_exec($comando);

        // Imprimir o manejar el resultado como desees
        echo "<div>Resultado de la ejecución del script:<br>$resultado</div>";
    }
    ?>

    <form action="../index.php">
        <button type="submit" class="volver-btn">Volver a inicio</button>
    </form>
</div>

</body>
</html>

