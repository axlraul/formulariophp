<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envío planificaciones APARS/IPL - Paso de comprobación</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        pre {
            background-color: #fff;
            padding: 10px;
            border: 1px solid #ddd;
            white-space: pre-wrap; /* Permite saltos de línea */
        }

        form {
            text-align: center;
            margin-top: 20px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h2>Envío planificaciones APARS/IPL - Paso de comprobación</h2>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $script_validacion_planificacion = '/tools/scripts/notificaciones-apars_ipl/validate_planification.sh';
        $planificacion_introducida = $_POST['planificacion_introducida'];
        $tipo_planificacion = $_POST['tipo_planificacion'];
        $archivo = '/tools/scripts/notificaciones-apars_ipl/planification/planification_list.txt';
        $nombre_tecnico = $_POST['nombre_tecnico'];

        // check if file $archivo is writable
        if (is_writable($archivo)) {
            // save content to a file and tipo_planificacio
            $contenido = preg_replace("/\r+/", "", $planificacion_introducida);
            if (file_put_contents($archivo, $contenido) !== false) {
                $output_script_1 = shell_exec("$script_validacion_planificacion $tipo_planificacion $nombre_tecnico 2>&1");

                echo "Resultado comprobación previo envío planificación:<br>";
                echo "<pre>$output_script_1</pre>";  // Utilizando <pre> para conservar el formato del texto

                // Adding bottom to redirect to another php file
                echo '<form action="resultado.php" method="post">';
                echo '<input type="hidden" name="nombre_tecnico" value="' . htmlspecialchars($nombre_tecnico) . '">';
                echo '<input type="hidden" name="tipo_planificacion" value="' . htmlspecialchars($tipo_planificacion) . '">';
                echo '<input type="submit" name="enviar_planificacion" value="Enviar planificación">';
                echo '</form>';
            } else {
                echo "Error al escribir en el archivo.";
            }
        } else {
            echo "El archivo no es escribible. Verifica los permisos.";
        }
    } else {
        echo "Acceso no permitido.";
    }
    ?>
</body>
</html>

