<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envío planificaciones APARS/IPL a aplicación automatizado</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        p {
            text-align: left; /* Alineado a la izquierda */
            margin-bottom: 10px;
        }

        form {
            text-align: left;
            margin: 0 auto;
            width: 80%;
        }

        textarea {
            width: 50%;
            height: 400px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            color: #777; /* Color gris */
            white-space: pre-line; /* Mantiene los saltos de línea del texto */
        }

        label {
            font-weight: bold;
            color: #007bff;
        }

        select {
            width: 130px;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            display: inline-block; /* Pone los desplegables en la misma línea */
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        function validateForm() {
            var tipoPlanificacion = document.getElementById("tipo_planificacion").value;
            var nombreTecnico = document.getElementById("nombre_tecnico").value;

            if (tipoPlanificacion === "" || nombreTecnico === "") {
                alert("Por favor, selecciona todas las opciones antes de enviar.");
                return false;
            }

            return true;
        }

        function clearDefaultText() {
            var textarea = document.getElementById("planificacion_introducida");
            var defaultText = "NODO1\nTIPO_CAMBIO\nCHMAXIMO\nDD/MM/AAAA HH:MM:SS\nNODO2\nTIPO_CAMBIO\nCHMAXIMO\nDD/MM/AAAA HH:MM:SS";
            if (textarea.value === defaultText) {
                textarea.value = "";
            }
        }
    </script>
</head>
<body>
    <h2>Envío planificaciones APARS/IPL a aplicación automatizado</h2>
    <form action="check-previo-envio.php" method="post" onsubmit="return validateForm()">
        <br>
        <p> Introduce la planificación recibida por ACS:</p>
        <textarea id="planificacion_introducida" name="planificacion_introducida" rows="10" required
            onfocus="clearDefaultText()">NODO1
TIPO_CAMBIO
CHMAXIMO
DD/MM/AAAA HH:MM:SS
NODO2
TIPO_CAMBIO
CHMAXIMO
DD/MM/AAAA HH:MM:SS</textarea>
        <br>

        <label for="opciones_planificacion">Tipo de planificación</label>
        <select id="tipo_planificacion" name="tipo_planificacion">
            <option value="" disabled selected>Selecciona</option>
            <option value="A">APARS SO</option>
            <option value="APACHE">APARS APACHE</option>
            <option value="I">IPL</option>
        </select>

        <label for="opciones_tecnicos">Nombre del técnico</label>
        <select id="nombre_tecnico" name="nombre_tecnico">
            <option value="" disabled selected>Selecciona</option>
            <option value="RAULPS">Raúl Pérez</option>
            <option value="JOSEMMC">Jose Manero</option>
            <option value="JOSEAAS">Sotoca</option>
            <option value="JACOBOAE">Jacobo Arvelo</option>
            <option value="SERGISD">Sergi Surroca</option>
            <option value="JORDIFG">Jordi Francés</option>
        </select>

        <br><br>

        <input type="submit" value="Guardar y ejecutar">
    </form>
</body>
</html>

