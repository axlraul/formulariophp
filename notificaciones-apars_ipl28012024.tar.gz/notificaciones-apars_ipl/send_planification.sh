#!/bin/bash
PATH_BASE="/tools/scripts/notificaciones-apars_ipl"
INVENTORY="$PATH_BASE/inventory/inventory.txt"
fecha_hora=$(date "+%d%m%y-%H%M%S")
anyo_actual=$(date +'%Y')
mail_TTSS='bgitnow.unix.seguridad@itnow.es'
##mail_TTSS_CC='rperezs@externos.itnow.es'
TECHNICIAN_TAG="$2"
listado_planificacion="$PATH_BASE/planification/planification_list-$TECHNICIAN_TAG.txt"
DIR_MAILS="MAILS"
#random_number=$((RANDOM % 90000 + 10000))

#randomize planification_list values
#cp $PATH_BASE/planification/planification_list.txt $PATH_BASE/planification/planification_list$random_number.txt
#listado_planificacion="$PATH_BASE/planification/planification_list$random_number.txt"


# Inicializar variables
nodo=""
tipo_cambio=""
cambio=""
fecha=""
so=""
system_found=""
mail_para=""
mail_cc=""
file_body_mail=""

##if [[ $(cat $listado_planificacion | grep PLANIFICACION_ENVIADA | wc -l) != 0 ]];then
##    echo "El listado introducido en $listado_planificacion ya ha sido enviado. Revisa el listado"
##    exit 0
##fi

## Limpiando e-mails enviados anteriormente
#rm -Rf $PATH_BASE/escalation/$DIR_MAILS/*
## Limpiando planificaciones enviadas anteriormente
#rm -Rf $PATH_BASE/escalation/ICS/*

#clear
echo "-------------------------------------------"
echo "Automatizacion de notificaciones APARS/IPL"
echo "Raul Perez"
echo "TS Linux Infra Corp"
echo "20/01/2024"
echo "-------------------------------------------"
#echo "Elige una opcion:"
#echo "A)      APARS SO"
#echo "APACHE) APARS APACHE"
#echo "I)      IPL"
#echo "q) Salir" 
#echo ""
#echo ""
#read preferencia

case "$1" in
  "A")
    TIPO_PLANIFICACION='APARS_SO'
    ;;
  "APACHE")
    TIPO_PLANIFICACION='APARS_APACHE'
    ;;
  "I")
    TIPO_PLANIFICACION='IPL'
    ;;
  "q")
    echo "Saliendo del programa."
    exit 0
    ;;
  *)
    echo "Opcion no valida. Por favor, ingresa 'A' o 'I'."
    exit 1
    ;;
esac

case $TECHNICIAN_TAG in
   RAULPS)
     TECHNICIAN_FULLNAME='Raúl Pérez Sanchiz'
     ;;
   JOSEMMC)
     TECHNICIAN_FULLNAME='Jose María Manero Caballero'
     ;;
   JOSEAAS)
     TECHNICIAN_FULLNAME='Jose Antonio Álvarez Sotoca'
     ;;
   JACOBOAE)
     TECHNICIAN_FULLNAME='Jacobo Saúl Arvelo Estevez'
     ;;
   SERGISD)
     TECHNICIAN_FULLNAME='Sergi Surroca Díaz'
     ;;
   JORDIFG)
     TECHNICIAN_FULLNAME='Jordi Francés García'
     ;;
esac


echo ""
echo "Tipo planificacion elegida: $TIPO_PLANIFICACION"

echo "Planificacion a enviar por $TECHNICIAN_FULLNAME"
echo ""
while IFS= read -r linea; do
    case $((contador % 5)) in
        0)
            nodo="$linea"
            if [[ $(cat $INVENTORY | grep $nodo | wc -l) != 1 ]]; then
               echo "ERROR - El nodo $nodo no se encuentra en inventory/inventory.txt. Corrígelo en el apartado web 'Gestión contactos de Sistema'"
               exit 1
            fi
#            system_found="$(cat $INVENTORY | grep -w $linea | egrep -i "linux|red hat" | awk '{print $2}')"
            system_found="$(cat $INVENTORY | grep -w $linea | awk '{print $2}')"

            ;;
        1)
            tipo_cambio="$linea"
            ;;
        2)
            cambio="$linea"
            ;;
        3)
            fecha="$linea"
            ;;
        4)
            so="$linea"
            if [[ $(echo $so | egrep -i "linux|red" | wc -l) == 0 ]]; then
               echo "ERROR - El nodo $nodo no es de un sistema Linux o Red Hat. Es SO $so Revisa el listado inventory/inventory.txt y el nombre del nodo antes de continuar"
#               exit 1
            fi            

  
#            # Mostrar la informacion por pantalla
#            echo "Nodo: $nodo"
#            echo "Sistema: $system_found"
#            echo "Tipo de cambio: $tipo_cambio"
#            echo "Codigo de cambio: $cambio"
#            echo "Fecha: $fecha"
#            echo "SO: $so"
               


#    if [[ -f "$PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found" ]]; then
#      if [[ $(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | grep "PARA:" | wc -l) == 1 ]]; then
#         mail_para="$(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | grep "PARA:" | awk -F "\"" '{print $2}')"
#      else
#         echo "ERROR - Faltan los destinatarios en PARA para el sistema $system_found. Corrígelo en el apartado web 'Gestión contactos de Sistema'"
#         echo "ERROR - Faltan los destinatarios en PARA para el sistema $system_found. Corrígelo en el apartado web 'Gestión contactos de Sistema'" >> $PATH_BASE/escalation/MAILS/$system_found-$TECHNICIAN_TAG
#      fi
#      if [[ $(grep "CC:" $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | wc -l) == 1 ]]; then
#         mail_cc="$(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | grep "CC:" | awk -F "\"" '{print $2}')"
#      else
#         echo "ERROR - Faltan los destinatarios en CC para el sistema $system_found. Corrígelo en el apartado web 'Gestión contactos de Sistema'" 
#         echo "ERROR - Faltan los destinatarios en CC para el sistema $system_found. Corrígelo en el apartado web 'Gestión contactos de Sistema'"  >> $PATH_BASE/escalation/MAILS/$system_found-$TECHNICIAN_TAG
#      fi
#
#      if [[ $(grep "TS:" $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | wc -l) == 1 ]]; then
#         mail_TTSS_CC="$(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_found | grep "TS:" | awk -F "\"" '{print $2}')"
#      fi
#
#
#
#    else
#         echo "ERROR - Archivo de escalado escalation/CONTACTS_SYSTEMS/$system_found no existe. Corrígelo en el apartado web 'Gestión contactos de Sistema'"
#         echo "ERROR - Archivo de escalado escalation/CONTACTS_SYSTEMS/$system_found no existe. Corrígelo en el apartado web 'Gestión contactos de Sistema'"
#    fi

######
mail_TTSS_CC="rperezs@externos.itnow.es"  ##se debe eliminar la linea cuando se implemente el script final
#####

     echo -e "${nodo[$i]}\t${system_found[$i]}\t${tipo_cambio[$i]}\t${cambio[$i]}\t${fecha[$i]}\t${so[$i]}"  >> $PATH_BASE/escalation/HISTORICO/HISTORICO-$anyo_actual.txt

#ok!     printf "%-15s %-15s %-15s %-15s %-25s %-25s\n" "${nodo[$i]}" "${system_found[$i]}" "${tipo_cambio[$i]}" "${cambio[$i]}" "${fecha[$i]}" "${so[$i]}" >> $PATH_BASE/escalation/MAILS/$system_found-$TECHNICIAN_TAG

     echo -e "<tr><th>${nodo[$i]}</th><th>${system_found[$i]}</th><th>${tipo_cambio[$i]}</th><th>${cambio[$i]}</th><th>${fecha[$i]}</th><th>${so[$i]}</th></tr>" >> $PATH_BASE/escalation/MAILS/$system_found-$TECHNICIAN_TAG

#    echo "Nodo: $nodo" >> escalation/MAILS/$system_found
#    echo "Sistema: $system_found" >> escalation/MAILS/$system_found
#    echo "Tipo de cambio: $tipo_cambio" >> escalation/MAILS/$system_found
#    echo "Codigo de cambio: $cambio" >> escalation/MAILS/$system_found
#    echo "Fecha: $fecha" >> escalation/MAILS/$system_found
#    echo "SO: $so" >> escalation/MAILS/$system_found
#    echo "-----------" >> escalation/MAILS/$system_found

### creacion del archivo ics para calendarizar el evento


day_ics=$(echo $fecha | cut -c 1,2) 
month_ics=$(echo $fecha | cut -c 4,5)
year_ics=$(echo $fecha | cut -c 7,8,9,10)
hour_ics=$(echo $fecha | cut -c 12,13)
min_ics=$(echo $fecha | cut -c 15,16)
sec_ics=$(echo $fecha | cut -c 18,19)


echo "BEGIN:VCALENDAR" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics
echo "VERSION:2.0" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics
echo "PRODID:-//ITNOW//$system_found" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics
echo "BEGIN:VEVENT" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics
echo "SUMMARY:$cambio - $nodo - $TIPO_PLANIFICACION - $fecha" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics
echo "ORGANIZER:mailto:$mail_TTSS_CC" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics
echo "DTSTART:${year_ics}${month_ics}${day_ics}T${hour_ics}${min_ics}${sec_ics}" >> "${PATH_BASE}/escalation/ICS/${nodo}-${cambio}-$TECHNICIAN_TAG.ics"
#echo "DTEND:${year_ics}${month_ics}${day_ics}T${hour_ics}${min_ics}${sec_ics}" >> "${PATH_BASE}/escalation/ICS/${nodo}-${cambio}-$TECHNICIAN_TAG.ics"
echo "END:VEVENT" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics
echo "END:VCALENDAR" >> $PATH_BASE/escalation/ICS/$nodo-$cambio-$TECHNICIAN_TAG.ics

    unset day_ics
    unset mont_ics
    unset year_ics
    unset hour_ics
    unset min_ics
    unset sec_ics

    unset nodo
    unset system_found
    unset tipo_cambio
    unset cambio
    unset fecha
    unset so
    unset mail_para
    unset mail_cc
      esac

    # Incrementar el contador
    ((contador++))
done < "$listado_planificacion"


##Sending all emails builded before

BODY_MAILS=$(find "$PATH_BASE/escalation/$DIR_MAILS" -type f -name "*-$TECHNICIAN_TAG*")
for file_body_mail in $BODY_MAILS; do
    system_name=$(echo $file_body_mail | awk -F "/" '{print $7}' | awk -F "-" '{print $1}')
    if [[ $(grep -i 'error' $file_body_mail | wc -l) != 0 ]]; then
        echo "ERROR - No se ha podido enviar la planificacion del sistema $system_name por detectar errores. +INFO revisar $file_body_mail"
    else 
        echo "OK - Enviando e-mail de sistema $system_name..."

         if [[ -f "$PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_name" ]]; then
             if [[ $(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_name | grep "PARA:" | wc -l) == 1 ]]; then
                 mail_para="$(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_name | grep "PARA:" | awk -F "\"" '{print $2}')"
#echo "PARA: $mail_para"
             fi
             if [[ $(grep "CC:" $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_name | wc -l) == 1 ]]; then
                 mail_cc="$(cat $PATH_BASE/escalation/CONTACTS_SYSTEMS/$system_name | grep "CC:" | awk -F "\"" '{print $2}')"
#echo "CC: $mail_cc"
             fi
         fi 

    #composicion del mail final a enviar + envio del mail + guardado copia seguridad del mail enviado
    cat $PATH_BASE/escalation/TEMPLATES/TOP_$TIPO_PLANIFICACION.txt $file_body_mail $PATH_BASE/escalation/TEMPLATES/BOTTOM_$TIPO_PLANIFICACION.txt $PATH_BASE/escalation/TEMPLATES/TECH_$TECHNICIAN_TAG.txt $PATH_BASE/escalation/TEMPLATES/SIGNATURE.txt>> $PATH_BASE/escalation/SENT_MAILS/$system_name-$TIPO_PLANIFICACION-TO_SEND
#mutt -e 'set content_type=text/html' -s 'hello' 'bgitnow.unix.seguridad@itnow.es' < prueba.html

#mutt -e 'set content_type=text/html' -s '[MMAIL] Planificacion APARS_SO' -c rperezsCC@externos.itnow.es,raul.perezsanchizCC@experis.es,bgitnow.unix.seguridad@itnow.es 'bgitnow.unix.seguridad@itnow.es' < $PATH_BASE/escalation/SENT_MAILS/MMAIL-APARS_SO-200124-151014
#mutt -e 'set content_type=text/html' -s '[MMAIL] Planificacion APARS_SO' -c rperezs@externos.itnow.es,raul.perezsanchizCC@experis.es 'rperezs@externos.itnow.es,raul.perezsanchiz@experis.es' < /tools/scripts/notificaciones-apars_ipl//escalation/SENT_MAILS/MMAIL-APARS_SO-200124-170132


mutt -e 'set content_type=text/html' -s "[$system_name] Planificacion $TIPO_PLANIFICACION" -c "rperezs@externos.itnow.es" "jmmanero@externos.itnow.es" < $PATH_BASE/escalation/SENT_MAILS/$system_name-$TIPO_PLANIFICACION-TO_SEND

#OK - mutt -e 'set content_type=text/html' -s "[$system_name] Planificacion $TIPO_PLANIFICACION" -c "$mail_TTSS_CC,$mail_cc" "$mail_para" < $PATH_BASE/escalation/SENT_MAILS/$system_name-$TIPO_PLANIFICACION-TO_SEND

mv $PATH_BASE/escalation/SENT_MAILS/$system_name-$TIPO_PLANIFICACION-TO_SEND  $PATH_BASE/escalation/SENT_MAILS/$system_name-$TIPO_PLANIFICACION-$fecha_hora

#    sed -i "1iPLANIFICACION_ENVIADA" "$listado_planificacion"

    fi
done



##Sending ICS to TS and TS_CC if defined

if [[ -z $mail_TTSS_CC ]]; then
   mutt  -s "$TIPO_PLANIFICACION - Eventos de calendario" $(printf -- '-a %q ' $PATH_BASE/escalation/ICS/*-$TECHNICIAN_TAG*) -- $mail_TTSS < $PATH_BASE/escalation/TEMPLATES/ICS.txt
else
   mutt  -s "$TIPO_PLANIFICACION - Eventos de calendario" $(printf -- '-a %q ' $PATH_BASE/escalation/ICS/*-$TECHNICIAN_TAG*) -c $mail_TTSS_CC -- $mail_TTSS < $PATH_BASE/escalation/TEMPLATES/ICS.txt
fi

#cleaning tmp files
rm -f $listado_planificacion
rm -f $PATH_BASE/escalation/ICS/*-$TECHNICIAN_TAG*
rm -f $PATH_BASE/escalation/MAILS/*-$TECHNICIAN_TAG

unset mail_TTSS_CC
unset system_name
unset file_body_mail
unset TIPO_PLANIFICACION
