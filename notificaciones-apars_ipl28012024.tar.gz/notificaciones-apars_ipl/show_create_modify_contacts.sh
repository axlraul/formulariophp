#!/bin/bash

PATH_BASE="/tools/scripts/notificaciones-apars_ipl/escalation"
arg1=$1 #crear / modificar / consultar
arg2=$2 #SISTEMA
arg3=$3 #PARA
arg4=$4 #CC
arg5=$5 #TS

if [[ $arg1 == 'consultar' ]]; then
  if [[ ! -e "$PATH_BASE/CONTACTS_SYSTEMS/$arg2" ]]; then
    echo "Contactos no estan presentes en $PATH_BASE/CONTACTS_SYSTEMS/$arg2. Utiliza la opcion Crear"
  else
    echo "Contactos del sistema $arg2:"
    cat $PATH_BASE/CONTACTS_SYSTEMS/$arg2
  fi
elif [[ $arg1 == 'crear' ]]; then
  if [[ ! -e "$PATH_BASE/CONTACTS_SYSTEMS/$arg2" ]]; then
     echo "PARA:\"$arg3\"" > $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     echo "CC:\"$arg4\"" >> $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     if [[ ! -z $arg5 ]]; then
        echo "TS:\"$arg5\"" >> $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     fi
     echo "Contactos del sistema $arg2 creados"
  else 
    echo "Contactos presentes en $PATH_BASE/CONTACTS_SYSTEMS/$arg2. Utiliza la opcion Consultar/Modificar."
  fi
elif [[ -e "$PATH_BASE/CONTACTS_SYSTEMS/$arg2" ]]; then
  if [[ $arg1 == 'modificar' ]]; then
     rm -f $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     echo "PARA:\"$arg3\"" > $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     echo "CC:\"$arg4\"" >> $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     if [[ ! -z $arg5 ]]; then
        echo "TS:\"$arg5\"" >> $PATH_BASE/CONTACTS_SYSTEMS/$arg2
     fi
     echo "Contactos del sistema $arg2 modificados"
  else 
    echo "Contactos no estan presentes en $PATH_BASE/CONTACTS_SYSTEMS/$arg2. Utiliza la opcion Crear"
  fi
fi

unset arg1
unset arg2
unset arg3
unset arg4
unset arg5
unset PATH_BASE
