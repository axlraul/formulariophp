<?php

// Nombre del archivo
$nombre_archivo = '/tools/scripts/notificaciones-apars_ipl/inventory/inventory.txt';

// Manejar el envío del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener valores del formulario
    $nodo = $_POST['nodo'];
    $sistema = $_POST['sistema'];
    $sistema_operativo = $_POST['sistema_operativo'];

    // Validar que no haya espacios en las variables nodo y sistema
    if (strpos($nodo, ' ') === false && strpos($sistema, ' ') === false) {
        // Construir la cadena para buscar en el archivo
        $linea_a_buscar = "$nodo $sistema $sistema_operativo";

        // Leer el contenido actual del archivo
        $contenido_actual = file_get_contents($nombre_archivo);

        // Dividir el contenido en líneas
        $lineas = explode(PHP_EOL, $contenido_actual);

        // Filtrar las líneas que no coincidan con los valores del formulario
        $lineas_filtradas = array_filter($lineas, function ($linea) use ($linea_a_buscar) {
            return trim($linea) !== trim($linea_a_buscar);
        });

        // Reconstruir el contenido sin las líneas eliminadas
        $contenido_actualizado = implode(PHP_EOL, $lineas_filtradas);

        // Escribir el contenido actualizado de vuelta al archivo
        file_put_contents($nombre_archivo, $contenido_actualizado);
        echo '<p class="mensaje-exito">Líneas eliminadas correctamente del archivo.</p>';
    } else {
        echo '<p class="mensaje-error">Error: Nodo y Sistema no deben contener espacios.</p>';
    }
}

?>

