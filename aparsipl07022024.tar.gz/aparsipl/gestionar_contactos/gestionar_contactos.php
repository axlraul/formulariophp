<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión contactos de Sistemas</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 20px 0;
            text-align: left;
        }

        li {
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
            margin-left: 140px;
        }

        a:hover {
            color: #0056b3;
        }

        #resultados {
            text-align: center;
            margin-top: 20px;
            position: relative;
        }

        #resultados p {
            font-size: 70%;
            margin: 0;
            display: inline-block; /* Coloca ambos párrafos en la misma línea */
        }

        /* estilo adicional para separar los dos párrafos */
        #resultados p + p {
            margin-top: 10px;
        }

        /* Agregado para el botón Volver a inicio */
        #volver {
            text-align: center;
            margin-top: 20px;
        }

        #volver button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        #volver button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <br>
    <h2>Gestión contactos de Sistemas</h2>
    <br>
    <br>
    <ul>
        <li><a href="gestionar_contactos_aplicativos.php">Gestión contactos aplicativos por Sistema</a></li>
        <li><a href="gestionar_direcciones_ts.php">Gestión de buzones de TS</a></li>
    </ul>

    <!-- Botón Volver a inicio -->
    <div id="volver">
        <button onclick="window.location.href='../index.php'">Volver a inicio</button>
    </div>
</body>
</html>

