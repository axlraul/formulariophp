<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de buzones TS</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        p {
            text-align: left;
            margin-bottom: 10px;
#            width: 120px;
        }

        form {
            text-align: left;
            margin: 0 auto;
            width: 80%;
        }

        textarea {
            width: 50%;
            height: 130px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            color: #777;
            white-space: pre-line;
        }

        label {
            font-weight: bold;
            color: #007bff;
            display: block;
            margin-bottom: 5px;
        }

        select {
            width: 120px; 
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            display: inline-block;
        }

        input[type="text"] {
            width: 80px;  
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            display: inline-block;
        }

        input[type="text"].expanded {
            width: 200px;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            display: inline-block;
        }

        input[type="submit"], input[type="button"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: #0056b3;
        }

        #output {
            margin-top: 120px;
            margin-bottom: 20px;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }

        strong {
            color: #333;
        }

        pre {
            background-color: #f8f8f8;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow-x: auto;
        }
    </style>
</head>
<body>

<form action="" method="post">
    <br>
    <h2>Gestión de buzones TS</h2>

    <p>
        <label for="campo_TS_sistemas">Técnica de sistemas:</label>
        <input type="text" name="campo_TS_sistemas" id="campo_TS_sistemas" maxlength="40" class="expanded example-text" value="I-SSO-XX-XX-XX-XX-XXXX" onfocus="if (this.value == 'I-SSO-XX-XX-XX-XX-XXXX') { this.value = ''; this.style.color = '#000'; }" onblur="if (this.value == '') { this.value = 'I-SSO-XX-XX-XX-XX-XXXX'; this.style.color = '#777'; }">
    </p>

    <p>
        <label for="opciones">Acción:</label>
        <select name="opciones" id="opciones">
            <option value="" disabled selected>Selecciona</option>
            <option value="crear">Crear</option>
            <option value="modificar">Modificar</option>
            <option value="consultar">Consultar</option>
        </select>
    </p>

    <div id="campos_crear_modificar" style="display: none;">
        <p>
            <label for="campo_email_ts">E-MAIL TS:</label>
            <input type="text" name="campo_email_ts" id="campo_email_ts" class="expanded example-text" placeholder="correo@ejemplo.com">
        </p>
    </div>

    <p>
        <input type="submit" value="Ejecutar acción">
        <input type="button" value="Volver a inicio" onclick="window.location.href='../index.php'">
    </p>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $opcionSeleccionada = $_POST["opciones"];
    $tsSistemas = $_POST["campo_TS_sistemas"];
    $emailTS = $_POST["campo_email_ts"];

    $script = "/tools/scripts/notificaciones-apars_ipl/show_create_modify_emails_TS.sh";

    // Construir la cadena de comandos
    $comando = "sh $script $opcionSeleccionada $tsSistemas $emailTS";

    // Ejecutar el script y obtener la salida
    $output = shell_exec($comando);

    // Mostrar la salida del script por pantalla
    echo '<div id="output"><strong>Resultado:</strong><br><pre>' . $output . '</pre></div>';
}
?>

<script>
    document.getElementById('opciones').addEventListener('change', function() {
        var camposCrearModificar = document.getElementById('campos_crear_modificar');
        camposCrearModificar.style.display = (this.value === 'crear' || this.value === 'modificar') ? 'block' : 'none';
    });
</script>

</body>
</html>

