<h1>Resultado envío planificación</h1>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_planificacion'])) {
    $tipo_planificacion = $_POST['tipo_planificacion'];
    $nombre_tecnico = $_POST['nombre_tecnico'];

    $script_envio_mail = '/tools/scripts/notificaciones-apars_ipl/send_planification.sh';

    // Ejecutar el script de Bash (o PHP) con la opción como argumento y obtener la salida
    $output_otro_php = shell_exec("$script_envio_mail $tipo_planificacion $nombre_tecnico 2>&1"); 

    echo "Resultado del envío de la planificación:<br>";
    echo "<pre>$output_otro_php</pre>";  // Utilizando <pre> para conservar el formato del texto
} else {
    echo "Acceso no permitido.";
}
?>
